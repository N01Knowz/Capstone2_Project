<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        p>img {
            max-width: 500px;
        }
    </style>
</head>
<body>
<p>Test question it is<img src="/user_upload_images/1696940349_6525413d4b566.jpeg" data-filename="sm0212petjpg-7a377c1c93f64d37.jpg" style="width: 25%;"></p>
</body>
</html><?php /**PATH D:\Ron\Ronron\Laravel\capstone2_project\resources\views/testview.blade.php ENDPATH**/ ?>