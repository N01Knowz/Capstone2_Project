<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="icon" href="/images/logo.png">
    <link rel="stylesheet" href="css/login.css">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;600&display=swap" rel="stylesheet">
</head>

<body>

    <div class="main-container">
        <div class="logoBackground">
            <div class="comLogo">
                <img src="images/logoWhite.png" id="logo">
            </div>
            <div class="photoBooks">
                <img src="images/background.png" id="background">
            </div>
        </div>
        <div class="loginContainer">
            <p id="loginWord">Login</p>
            <p id="welcomeSentence">Welcome to ADA!</p>
            <div class="form-container">
                <form method="POST" action="<?php echo e(route('login')); ?>" class="loginForm">
                    <?php echo csrf_field(); ?>
                    <p id="label">Email</p>
                    <input type="text" class="inputVariables" name="email">
                    <p id="label">Password</p>
                    <input type="password" class="inputVariables" name="password">
                    <button id="sign-in-button">Sign In</button>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger" style="color: red;">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </form>
            </div>
            <p id="register-sentence">New to ADA? <span><a href="register">Sign Up</a></span></p>
        </div>
    </div>
    <?php if(session('password_changed')): ?>
    <script>
        var message = "<?php echo e(session('password_changed')); ?>";
        var title = "Successfully Changed Password";
        alert(title + "\n\n" + message);
    </script>
    <?php endif; ?>
</body>

</html><?php /**PATH D:\Ron\Ronron\Laravel\capstone2_project\resources\views/auth/login.blade.php ENDPATH**/ ?>