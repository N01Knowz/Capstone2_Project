<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        p>img {
            max-width: 500px;
        }
    </style>
</head>
<body>
<p>testing testing<img src="user_upload_images/1692457071_64e0d86f531ac.jpeg" data-filename="5836.jpg" style="width: 1393.06px;"><br>testing 2<img src="user_upload_images/1692457071_64e0d86f537c1.png" data-filename="signature.png" style="width: 818px;"></p>
</body>
</html><?php /**PATH D:\Ron\Ronron\Laravel\capstone2_project\resources\views/testview.blade.php ENDPATH**/ ?>